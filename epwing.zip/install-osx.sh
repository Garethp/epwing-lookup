#!/usr/bin/env bash

./install-linux.sh osx "${1}"

